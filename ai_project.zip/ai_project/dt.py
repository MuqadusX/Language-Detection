import sys
import pandas as pd
import numpy as np
import re
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.simplefilter("ignore")

from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report
from sklearn.tree import DecisionTreeClassifier

import tkinter as tk
from tkinter import messagebox

from googletrans import Translator


data = pd.read_csv("language_detection.csv")
X = data["Text"]
Y = data["language"]

le = LabelEncoder()
Y = le.fit_transform(Y)

data_list = []
for text in X:
    text = re.sub(r'[!@#$(),"%^*?:;~`0-9\[\]]', '', text)
    text = text.lower()
    data_list.append(text)

cv = CountVectorizer()
X = cv.fit_transform(data_list)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.20)


decision_tree = DecisionTreeClassifier()
decision_tree.fit(x_train, y_train)
y_pred = decision_tree.predict(x_test)

ac = accuracy_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)
print(f'Decision Tree Accuracy = {round(ac * 100, 2)} %')

