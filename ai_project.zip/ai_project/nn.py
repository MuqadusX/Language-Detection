import sys
import pandas as pd
import numpy as np
import re
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.simplefilter("ignore")

from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

import tkinter as tk
from tkinter import messagebox

from googletrans import Translator
from tensorflow.keras.models import Sequential
from tensorflow.keras.layers import Dense, Dropout
from tensorflow.keras.utils import to_categorical

# Load and preprocess data
data = pd.read_csv("language_detection.csv")
X = data["Text"]
Y = data["language"]

le = LabelEncoder()
Y = le.fit_transform(Y)

data_list = []
for text in X:
    text = re.sub(r'[!@#$(),"%^*?:;~`0-9\[\]]', '', text)
    text = text.lower()
    data_list.append(text)

cv = CountVectorizer()
X = cv.fit_transform(data_list)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.20)

# Convert labels to categorical
y_train_categorical = to_categorical(y_train)
y_test_categorical = to_categorical(y_test)

# Build the neural network model
model = Sequential()
model.add(Dense(512, input_shape=(x_train.shape[1],), activation='relu'))
model.add(Dropout(0.3))
model.add(Dense(256, activation='relu'))
model.add(Dropout(0.3))
model.add(Dense(len(le.classes_), activation='softmax'))

model.compile(optimizer='adam', loss='categorical_crossentropy', metrics=['accuracy'])
model.summary()

history = model.fit(x_train, y_train_categorical, epochs=10, batch_size=64, validation_data=(x_test, y_test_categorical))

loss, accuracy = model.evaluate(x_test, y_test_categorical)
print(f'Accuracy = {round(accuracy * 100, 2)} %')

