import sys
import pandas as pd
import numpy as np
import re
import seaborn as sns
import matplotlib.pyplot as plt
import warnings
warnings.simplefilter("ignore")

from sklearn.preprocessing import LabelEncoder
from sklearn.feature_extraction.text import CountVectorizer
from sklearn.model_selection import train_test_split
from sklearn.naive_bayes import MultinomialNB
from sklearn.metrics import accuracy_score, confusion_matrix, classification_report

import tkinter as tk
from tkinter import messagebox

from googletrans import Translator

# Load and preprocess data
data = pd.read_csv("language_detection.csv")
X = data["Text"]
Y = data["language"]

le = LabelEncoder()
Y = le.fit_transform(Y)

data_list = []
for text in X:
    text = re.sub(r'[!@#$(),"%^*?:;~`0-9\[\]]', '', text)
    text = text.lower()
    data_list.append(text)

cv = CountVectorizer()
X = cv.fit_transform(data_list)
x_train, x_test, y_train, y_test = train_test_split(X, Y, test_size=0.20, random_state=42)

model = MultinomialNB()
model.fit(x_train, y_train)
y_pred = model.predict(x_test)

ac = accuracy_score(y_test, y_pred)
cm = confusion_matrix(y_test, y_pred)
print(f'accuracy = {round(ac * 100, 2)} %')

# Initialize the translator
translator = Translator()

# Predict function
def predict(text):
    text = re.sub(r'[!@#$(),"%^*?:;~`0-9\[\]]', '', text)
    text = text.lower()
    x = cv.transform([text]).toarray()
    lang = model.predict(x)
    lang = le.inverse_transform(lang)
    return lang[0]

# Function to identify language, translate to English, and update the result in GUI
def identify_language_gui():
    text = input_text.get("1.0", tk.END).strip()
    if text:
        sentences = re.split(r'(?<!\w\.\w.)(?<![A-Z][a-z]\.)(?<=\.|\?)\s', text)
        results = []
        translations = []
        for sentence in sentences:
            if sentence:
                lang = predict(sentence)
                try:
                    translation = translator.translate(sentence, src=lang, dest='en')
                    results.append(f'"{sentence}" - {lang}')
                    translations.append(f'"{translation.text}"')
                except Exception as e:
                    results.append(f'"{sentence}" - {lang}')
                    translations.append(f'Error in translation: {str(e)}')
        result.set("\n".join(results))
        translation_result.set("\n".join(translations))
    else:
        messagebox.showwarning("Input Error", "Please enter some text")

# Create the main window
root = tk.Tk()
root.title("Language Identification System")

# Set window size and background color
root.geometry("600x600")
root.configure(bg="#336b87")

# Create and place widgets
title_label = tk.Label(root, text="Language Identification System", font=("Arial", 20, "bold"), bg="#336b87", fg="white")
title_label.pack(pady=20)

input_label = tk.Label(root, text="Enter your text", font=("Arial", 14), bg="#336b87", fg="white")
input_label.pack(pady=5)

input_text = tk.Text(root, height=5, width=60, font=("Arial", 12), bg="#b3cde0", fg="black", wrap=tk.WORD)
input_text.pack(pady=10, padx=20)

identify_button = tk.Button(root, text="Identify", command=identify_language_gui, font=("Arial", 14), bg="#002c54", fg="white", activebackground="#004c8c")
identify_button.pack(pady=10)

result = tk.StringVar()
translation_result = tk.StringVar()

result_label_frame = tk.LabelFrame(root, text="Result", font=("Arial", 12), bg="#336b87", fg="white", labelanchor="n")
result_label_frame.pack(pady=5, padx=10, fill="both", expand=True)

result_label = tk.Label(result_label_frame, textvariable=result, font=("Arial", 12), bg="#b3cde0", fg="black", wraplength=500, justify="left")
result_label.pack(pady=5, padx=10, fill="both", expand=True)

translation_label_frame = tk.LabelFrame(root, text="Translation", font=("Arial", 12), bg="#336b87", fg="white", labelanchor="n")
translation_label_frame.pack(pady=5, padx=10, fill="both", expand=True)

translation_label = tk.Label(translation_label_frame, textvariable=translation_result, font=("Arial", 12), bg="#b3cde0", fg="black", wraplength=500, justify="left")
translation_label.pack(pady=5, padx=10, fill="both", expand=True)

# Run the application
root.mainloop()
